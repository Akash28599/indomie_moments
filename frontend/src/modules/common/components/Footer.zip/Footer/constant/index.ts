import {adminFooterConfig} from './footer.admin';
import {userFooterConfig} from './footer.user';


export{
    adminFooterConfig,
    userFooterConfig
}